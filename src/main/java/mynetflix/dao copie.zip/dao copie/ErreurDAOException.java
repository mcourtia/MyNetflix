package mynetflix.dao;

public class ErreurDAOException extends RuntimeException {
	
	public ErreurDAOException(String message) {
		super(message);
	}
}
